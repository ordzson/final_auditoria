import type { ReviewId } from '../audit/types';

/** Ayuda de lectura: no incorpora fuentes ni cambia las decisiones evaluables v2.1. */
export const reviewGuidance: Record<ReviewId, { terms: string; limit: string }> = {
  'AU-01': {
    terms: 'MFA (autenticación multifactor) exige factores distintos, como contraseña y código de una aplicación. VPN es una conexión privada a la red; API es una interfaz entre programas. Recertificar es revisar con el responsable qué cuentas y permisos siguen justificados.',
    limit: 'La sesión de ext_ops_04 no identifica a una persona ni enlaza por sí sola la elevación o la lectura SQL. La política y sus excepciones siguen pendientes.',
  },
  'AU-02': {
    terms: 'SQL es el lenguaje de consulta de datos; SELECT permite leerlos. Exfiltración significa salida no autorizada de información: el volumen de tráfico no identifica el contenido ni su autorización.',
    limit: 'Este editor consulta resúmenes locales. Q-01–Q-12 se ejecutaron en SQL Server en I2/I3 sobre datos sintéticos v2 y se documentan en los anexos académicos. Esos resultados reproducen señales; no corroboran el incidente de forma independiente.',
  },
  'AU-03': {
    terms: 'CRM es el sistema de gestión de clientes y órdenes. Conciliar significa comparar historial de órdenes y facturación para identificar y explicar diferencias. BD significa base de datos.',
    limit: 'El expediente reporta 216 órdenes. Los 144 cambios de monto y 72 de estado de Q-07 son diseño sintético, sin cuenta, sesión ni vía conocidas. Los diez pares candidatos de Q-08 no prueban doble cobro. La conciliación del incidente sigue pendiente.',
  },
  'AU-04': {
    terms: 'SIEM es el sistema que reúne registros y genera alertas de seguridad. La alerta reportada de las 03:18 no incluye asignación, primera acción ni cierre documentados.',
    limit: 'Los 61 minutos entre sesión y alerta y los 24 hasta la caída son diferencias de horas reportadas. No prueban tiempo de detección, inacción ni pérdida de registros; los relojes no están verificados.',
  },
  'AU-05': {
    terms: 'RTO es el tiempo objetivo para restablecer el servicio. RPO es la pérdida de datos tolerable expresada en tiempo. BIA es el análisis del impacto de una interrupción en el negocio.',
    limit: 'Los 315/355 minutos hasta consulta/escritura describen retorno reportado; no calculan el RPO ni prueban cumplimiento. En este incidente faltan el informe que identifique el respaldo usado y las pruebas de datos recuperados. El registro de julio del laboratorio es ficticio; no se ejecutó una restauración.',
  },
  'AU-06': {
    terms: 'Metadatos son datos sobre un archivo, como su ruta y procedencia. SHA-256 es una huella calculada de sus bytes. Compararla con una referencia previamente registrada permite detectar cambios; no demuestra verdad ni completitud. Hay que conservar el origen de esa referencia.',
    limit: 'Aquí se consultan metadatos del resumen, sin leer archivos ni calcular hashes. Los hashes de anexos sintéticos no autentican originales del incidente. AU-06 no sustituye PT-25: los permisos efectivos se comprobaron solo en laboratorio. B1-1/B1-2 siguen no concluyentes y pendientes de revisión humana y de P3.',
  },
};

export const documentedMeaning = '«Documentado» significa que se reunieron las fuentes y respuestas estructuradas exigidas para esta actividad educativa. Puede conservar una conclusión no concluyente; no aprueba hallazgos académicos, causalidad ni autoría.';
