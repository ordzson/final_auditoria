import type { ReviewId } from '../audit/types';
import { reviewGuidance } from '../data/guidance';
import { escapeHtml } from './dom';

export function reviewHelpMarkup(reviewId: ReviewId): string {
  const help = reviewGuidance[reviewId];
  return `<aside class="review-help" aria-label="Ayuda escrita de la revisión" data-review-help="${reviewId}"><p>${escapeHtml(help.terms)}</p><details><summary>Alcance frente a I4 y pendientes</summary><p>${escapeHtml(help.limit)}</p></details></aside>`;
}
